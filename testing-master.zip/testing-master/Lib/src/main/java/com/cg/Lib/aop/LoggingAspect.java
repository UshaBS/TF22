package com.cg.Lib.aop;

public class LoggingAspect {

}
