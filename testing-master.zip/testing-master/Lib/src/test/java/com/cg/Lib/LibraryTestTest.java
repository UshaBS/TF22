package com.cg.Lib;

import static org.junit.Assert.*;

import org.junit.Test;

public class LibraryTestTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
}
