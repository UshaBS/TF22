# api-artifacts-generator
Application that generates API Artifacts from provided Schema
