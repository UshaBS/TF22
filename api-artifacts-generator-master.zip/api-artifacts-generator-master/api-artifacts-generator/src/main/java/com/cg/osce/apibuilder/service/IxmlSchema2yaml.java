package com.cg.osce.apibuilder.service;

import java.util.Set;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cg.osce.apibuilder.FormWrapper;
import com.cg.osce.apibuilder.exception.APIBuilderException;
import com.cg.osce.apibuilder.pojo.Delete;
import com.cg.osce.apibuilder.pojo.Get;
import com.cg.osce.apibuilder.pojo.Post;
import com.cg.osce.apibuilder.pojo.Put;
import com.cg.osce.apibuilder.pojo.SwaggerSchema;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

public interface IxmlSchema2yaml {

	SwaggerSchema printYAML = null;

	public Post createDefaultPost(Class<? extends Object> entity, JsonNodeFactory factory) throws APIBuilderException;

	public Get createDefaultGet(Class<? extends Object> entity, JsonNodeFactory factory);

	public Put createDefaultPut(Class<? extends Object> entity, JsonNodeFactory factory) throws APIBuilderException;

	public Delete createDefaultDelete(Class<? extends Object> entity, JsonNodeFactory factory)
			throws APIBuilderException;

	public ObjectNode creteDefinitions(JsonNodeFactory factory);

	public Set<Class<? extends Object>> getClassDetails();

	public void handleFileUpload(FormWrapper formWrapper, RedirectAttributes redirectAttributes)
			throws APIBuilderException;

}
